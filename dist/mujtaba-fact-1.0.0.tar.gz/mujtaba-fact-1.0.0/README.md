# SaralGyaan Square
It takes an integer as an input and prints it factorial of that number.

## Installation
```pip install mujtaba-fact```

## How to use it?
Open terminal and type facts and then input the integer

## License

© 2022 Mujtaba Ali

This repository is licensed under the MIT license. See LICENSE for details.